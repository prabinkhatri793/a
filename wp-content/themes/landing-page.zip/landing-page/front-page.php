<?php get_header();?>


<!-- Start Games Sections -->
<section class="blogs bg-sec pt pb">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="quiz">
                    <?php echo do_shortcode('[ays_quiz id=\'6\']'); ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="">
                    <img src="<?php bloginfo('template_url'); ?>/images/happy-girl-with-laptop-professional-girl-image-png.png" class="img-responsive">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End App Sections -->

<!-- Banner End -->
<section class="about-us">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <?php get_sidebar();?>
            </div>
            <div class="col-md-8">
                <div class="content">
                    <?php while (have_posts()) : the_post(); ?>

                           <?php the_content(); ?>

                       <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Start Banner -->
<!-- Start Games Sections -->
<section class="blogs bg-sec pt pb">
    <div class="container">
        <div class="row">
            <div class="col-md-1">
            </div>
            <div class="col-md-2">
                <div class="">
                    <img src="<?php bloginfo('template_url'); ?>/images/man-design.png" class="img-responsive">
                </div>
            </div>
            <div class="col-md-9">
                <div class="quiz">
                    <?php echo do_shortcode('[ays_quiz id=\'2\']'); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End App Sections -->
<!-- Start Must Read Sections -->
<section class="blogs col-4-items pt pb">
    <div class="container">
        <div class="heading-section d-flex justify-content-between align-items-center">
            <div class="category-name">
                <h3>GWF Quiz </h3>
            </div>
            <div class="view-all">
                <a href="<?php echo get_category_link(get_cat_ID('software')); ?>"><i class="fas fa-long-arrow-alt-right"></i> View All</a>
            </div>
        </div>
        <div class="blog-posts">
            <div class="blog-main">
                <div class="row">
                    <?php 
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 4,
                        'orderby' => 'ID',
                        'order' => 'ASC'
                    );
                    $query = new WP_Query($args);
                    if ($query->have_posts()) {
                        while ($query->have_posts()) : $query->the_post(); ?>
                            <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                                <div class="blog-col">
                                    <div class="blog-media">
                                        <a href="<?php the_permalink(); ?>" title="">
                                            <div class="blog-image-container">
                                                <div class="image">
                                                     <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                                </div>
                                                <div class="blog-overlay">
                                                    <div class="blog-text">
                                                        <h3><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; 
                        wp_reset_postdata();
                    } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Must Read Sections -->
<!-- Start Games Sections -->
<section class="contact-us bg-sec pt pb">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="quiz">
                    <?php echo do_shortcode('[ays_quiz id=\'7\']'); ?>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form register">
                    <?php echo do_shortcode('[contact-form-7 id="f2c4bd2" title="Contact Us"]'); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End App Sections -->
<!-- Start Must Read Sections -->
<section class="blogs col-4-items pt pb">
    <div class="container">
        <div class="heading-section d-flex justify-content-between align-items-center">
            <div class="category-name">
                <h3>Popular GWF Quiz </h3>
            </div>
            <div class="view-all">
                <a href="<?php echo get_category_link(get_cat_ID('software')); ?>"><i class="fas fa-long-arrow-alt-right"></i> View All</a>
            </div>
        </div>
        <div class="blog-posts">
            <div class="blog-main">
                <div class="row">
                    <?php 
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 4,
                        'meta_key' => 'post_views', // Custom field for view count
                        'orderby' => 'meta_value_num', // Order by view count
                        'order' => 'ASC'
                    );
                    $query = new WP_Query($args);
                    if ($query->have_posts()) {
                        while ($query->have_posts()) : $query->the_post(); ?>
                            <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-3">
                                <div class="blog-col">
                                    <div class="blog-media">
                                        <a href="<?php the_permalink(); ?>" title="">
                                            <div class="blog-image-container">
                                                <div class="image">
                                                     <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php echo get_post_meta(get_post_thumbnail_id(), '_wp_attachment_image_alt', true); ?>">
                                                </div>
                                                <div class="blog-overlay">
                                                    <div class="blog-text">
                                                        <h3><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; 
                        wp_reset_postdata();
                    } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Must Read Sections -->
<?php get_footer(); ?>






