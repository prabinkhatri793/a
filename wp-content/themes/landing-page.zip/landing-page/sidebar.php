 <div class="blog-sidebar">
    <div class="blog-sidebar-wrap">
      <div class="heading-section d-flex justify-content-between align-items-center">
        <div class="category-name">
            <h3>GWF Quizzes</h3>
        </div>
    </div>
      <ul>
         <?php
            wp_nav_menu( array(
                'theme_location' => 'quick_links',
                'menu_class'     => 'footer-menu-list',
                'container'      => false,
            ) );
            ?>
      </ul>
    </div>
    
</div>