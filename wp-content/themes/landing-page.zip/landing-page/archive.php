<?php get_header();?>


    <!-- Banner -->
    <section class="banner inner-page">
        <div class="container">
            <div class="banner-wrap">
                <h1><?php the_title();?></span></h1>
            </div>
        </div>
    </section>
    
    <?php while(have_posts()):the_post();?>
    <div class="pt-5 pb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <?php get_sidebar();?>
                </div>
                <div class="col-md-8">
                    <div class="blog-details-main">
                        <div class="blog-details-content">
                            <div class="quiz">
                            </div>
                        </div>
                    </div>
                    
                    <!-- End Must Read Sections -->

                </div>
            </div>
        </div>
    </div>
    <?php endwhile;?> 

    
    <!-- Location -->

    <style>
        div#exampleModalCenter {
            z-index: 99999 !important;
        }
        .modal-body {
            padding: 0px;
        }
    </style>
<?php get_footer();?>