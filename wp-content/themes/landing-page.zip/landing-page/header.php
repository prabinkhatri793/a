<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="" content="" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z"
          crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.2/css/all.css"
          integrity="sha384-vSIIfh2YWi9wW0r9iZe7RJPrKwp6bG+s9QZMoITbCckVJqGCCRhc+ccxNcdpHuYu"
          crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/stellarnav.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/style.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/responsive.css">
    
<?php wp_head(); ?>


</head>

<body>
   

<head>
<div class="sn-header navigation-bar stick bg-transparent">
    <div class="container mx-auto px-4">
        <nav class="flex items-center justify-between py-4">
            <a class="logo" href="<?php echo home_url(); ?>" title="logo">
                <h2 style="color:#048b86;">GWF Quiz</h2>
            </a>
            <div class="menu mr-4">
                <?php
                wp_nav_menu(array('theme_location' => 'menu-1', 'container_class' => 'stellarnav'));
                ?>
            </div>
            <!-- <div class="search-bar hidden md:flex items-center">
              <form action="<?php echo home_url();?>" method="get" class="flex items-center">
                <input type="text" name="s" placeholder="Search..." class="form-control px-2 py-1">
                <button type="submit" class="btn px-2 py-1"><i class="fas fa-search" aria-hidden="true"></i></button>
              </form>
            </div> -->
            <!-- Website logos Pop Bottom -->
            <?php if ( is_active_sidebar( 'custom-widget-area' ) ) : ?>
                <div id="custom-widget-area" class="widget-area">
                    <?php dynamic_sidebar( 'custom-widget-area' ); ?>
                </div>
            <?php endif; ?>

        </nav>
    </div>
</div>
<script>
    function toggleWebLinks(event) {
        const webLinks = document.getElementById('web-links');
        webLinks.classList.toggle('hidden');
    }

    // Close #web-links when clicking outside of it
    document.addEventListener('click', function(event) {
        const webLinks = document.getElementById('web-links');
        const webButton = document.querySelector('.web-button');

        // If the click is outside #web-links and not on the toggle button
        if (!webLinks.contains(event.target) && !webButton.contains(event.target)) {
            webLinks.classList.add('hidden');
        }
    });
</script>
</head>

